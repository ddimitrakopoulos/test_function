using System.Net;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace TestFunctions;

public class HttpTestFunctions
{
    private readonly ILogger _logger;

    public HttpTestFunctions(ILoggerFactory loggerFactory)
    {
        _logger = loggerFactory.CreateLogger<HttpTestFunctions>();
    }

    [Function("Ping")]
    public HttpResponseData Ping(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "ping")] HttpRequestData req)
    {
        _logger.LogInformation("Ping function processed a request.");

        var response = req.CreateResponse(HttpStatusCode.OK);
        response.Headers.Add("Content-Type", "application/json");
        response.WriteString(JsonSerializer.Serialize(new
        {
            ok = true,
            service = "couponing-function-test",
            utc = DateTime.UtcNow,
            message = "Function app is alive"
        }));

        return response;
    }

    [Function("Echo")]
    public async Task<HttpResponseData> Echo(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = "echo")] HttpRequestData req)
    {
        _logger.LogInformation("Echo function processed a request.");

        string body = await new StreamReader(req.Body).ReadToEndAsync();
        var payload = new
        {
            method = req.Method,
            query = req.Url.Query,
            body,
            utc = DateTime.UtcNow
        };

        var response = req.CreateResponse(HttpStatusCode.OK);
        response.Headers.Add("Content-Type", "application/json");
        response.WriteString(JsonSerializer.Serialize(payload));
        return response;
    }

    [Function("SampleCoupons")]
    public HttpResponseData SampleCoupons(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "coupons/{count:int?}")] HttpRequestData req,
        int? count)
    {
        int size = Math.Clamp(count ?? 3, 1, 20);
        var coupons = Enumerable.Range(1, size).Select(i => new
        {
            code = $"TEST-{DateTime.UtcNow:yyyyMMdd}-{i:000}",
            discountPercent = 5 * i,
            expiresUtc = DateTime.UtcNow.AddDays(i)
        });

        var response = req.CreateResponse(HttpStatusCode.OK);
        response.Headers.Add("Content-Type", "application/json");
        response.WriteString(JsonSerializer.Serialize(new
        {
            total = size,
            items = coupons,
            note = "Synthetic test coupons"
        }));

        return response;
    }
}
